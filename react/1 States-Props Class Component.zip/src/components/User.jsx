let User = () => {
  return (
    <>
      <h1 className="bg-green">Welcome to user</h1>
    </>
  );
};

export default User;

// bs4 ==> ml , mr
// bs5 ==> ms , me
