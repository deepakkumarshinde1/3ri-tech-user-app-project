// import is optional
import UserCLass from "./components/UserClass";

// function component
// logic
let App = () => {
  return (
    <>
      <UserCLass newText="Welcome Suraj" value2="sample" />
    </>
  );
};

// export
export default App;
