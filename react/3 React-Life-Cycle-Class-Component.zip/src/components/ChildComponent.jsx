import React from "react";

class ChildComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 0 };
    console.log("constructor");
  }
  incCount = () => {
    this.setState((state) => ({ ...state, count: state.count + 1 }));
  };

  componentDidMount() {
    console.log("Mount i can call api");
  }

  componentDidUpdate() {
    console.log("Update i can call api");
  }

  componentWillUnmount() {
    console.log("componentWillUnmount");
  }

  render() {
    return (
      <>
        <hr />
        <center>
          <button onClick={this.incCount}>INC Count</button>
          <h1>{this.state.count}</h1>
        </center>
      </>
    );
  }
}

export default ChildComponent;
