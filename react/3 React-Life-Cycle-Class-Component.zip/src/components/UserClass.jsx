import React from "react";
import ChildComponent from "./ChildComponent";

class UserCLass extends React.Component {
  constructor(props) {
    super(props);
    this.state = { toggle: false };
  }

  setToggle = () => {
    this.setState((state) => ({ ...state, toggle: !state.toggle }));
  };
  render() {
    return (
      <>
        <center>
          <button onClick={this.setToggle}>Toggle</button>
          <h1>{Number(this.state.toggle)}</h1>
        </center>
        {this.state.toggle === true ? null : <ChildComponent />}
      </>
    );
  }
}

export default UserCLass;

// bs4 ==> ml , mr
// bs5 ==> ms , me

// Legacy Project
// Class  < 16.8 < Function (Hooks functions)

// store "Welcome User" in a variable
// Events ==> User Action
