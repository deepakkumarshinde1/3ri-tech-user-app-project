import { combineReducers } from "@reduxjs/toolkit";
import WeatherReducer from "./WeatherReducer";
const reducer = combineReducers({
  weather: WeatherReducer,
});

export default reducer;
