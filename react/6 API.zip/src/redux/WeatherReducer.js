import { createSlice } from "@reduxjs/toolkit";

let WeatherSlice = createSlice({
  name: "weather",
  initialState: {
    weatherDetails: null,
  },
  reducers: {
    saveWeatherDetails: (state, action) => {
      state.weatherDetails = action.payload;
    },
  },
});

export default WeatherSlice.reducer;
export const { saveWeatherDetails } = WeatherSlice.actions;
