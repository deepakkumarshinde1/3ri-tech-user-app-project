import { memo, useEffect, useState } from "react";

const Text = (props) => {
  let [text, setText] = useState(1); // in return it gives array [value,updateValueFunction]
  //   useState => you can pass :: number , string , boolean , null , array , object
  let [text1, setText1] = useState(1);
  let changeText = () => {
    setText(++text);
  };

  let changeText1 = () => {
    setText1(++text1);
  };

  // mounting
  useEffect(() => {
    console.log("api call mounting");

    return () => {
      // unmounting
      console.log("unmounting");
    };
  }, []); // only once

  // update
  useEffect(() => {
    console.log("api call updating");
  }, [text]);

  return (
    <>
      <center>
        <h1>Text {text}</h1>
        <button onClick={changeText}>Change Text</button>

        <h1>Text {text1}</h1>
        <button onClick={changeText1}>Change Text</button>
      </center>
    </>
  );
};

export default memo(Text);
