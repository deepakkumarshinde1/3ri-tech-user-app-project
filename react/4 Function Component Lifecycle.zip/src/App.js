// import is optional

import { useState } from "react";
import Text from "./components/Text";

// function component
// logic
let App = () => {
  let [toggle, setToggle] = useState(false);
  let changeData = () => {
    setToggle(!toggle);
  };
  return (
    <>
      <center>
        <button onClick={changeData}>Toggle</button>
        <h1>{Number(toggle)}</h1>
      </center>
      <hr />
      {toggle === true ? null : <Text newText="Pritam" />}
    </>
  );
};

// export
export default App;
