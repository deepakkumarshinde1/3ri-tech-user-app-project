let PageNotFound = () => {
  return (
    <>
      <p className="text-center display-1 text-danger mt-5">
        404 Page Not Found
      </p>
    </>
  );
};

export default PageNotFound;
