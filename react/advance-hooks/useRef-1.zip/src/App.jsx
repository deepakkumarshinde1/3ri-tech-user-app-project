import Input from "./components/Input";
function App() {
  return (
    <>
      <Input />
    </>
  );
}

export default App;
