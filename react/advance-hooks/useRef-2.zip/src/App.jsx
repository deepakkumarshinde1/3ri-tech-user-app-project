import { useEffect, useRef } from "react";
import Input from "./components/Input";
function App() {
  let inputRef = useRef();
  let submit = () => {
    console.log(inputRef.current.getMyValue());
  };
  useEffect(() => {
    inputRef.current.setLabelText("Label from parent to child");
  }, []);
  return (
    <>
      <Input ref={inputRef} />
      <button onClick={submit}>Submit</button>
    </>
  );
}

export default App;
