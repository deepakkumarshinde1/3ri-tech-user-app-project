function abc<Type>(value: Type) {
  console.log(value);
}

abc(1);

// == data
// === data + dataType
