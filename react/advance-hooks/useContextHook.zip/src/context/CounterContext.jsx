import { createContext, useContext, useState } from "react";

// context (initial value)
let CounterContext = createContext({});

// provider => component
export let CounterContextProvider = (props) => {
  const [counters, setCounters] = useState([]);
  const updateCounter = (index) => {
    counters[index] += 1;
    setCounters([...counters]);
  };

  const addCounter = () => {
    setCounters([...counters, 0]);
  };
  const deleteCounter = (index) => {
    counters.splice(index, 1);
    setCounters([...counters]);
  };
  let value = { counters, updateCounter, addCounter, deleteCounter };
  return (
    <CounterContext.Provider value={value}>
      {props.children}
    </CounterContext.Provider>
  );
};
// custom hook
export let useCounterContext = () => {
  return useContext(CounterContext);
};
