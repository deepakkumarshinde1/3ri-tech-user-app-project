import AddCounter from "./components/AddCounter";
import Counter from "./components/Counter";
import { useCounterContext } from "./context/CounterContext";

function App() {
  let { counters } = useCounterContext();
  return (
    <>
      <AddCounter />
      {counters.map((value, index) => {
        return <Counter key={index} index={index} count={value} />;
      })}
    </>
  );
}

export default App;
