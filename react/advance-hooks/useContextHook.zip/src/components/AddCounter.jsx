import { useCounterContext } from "../context/CounterContext";

function AddCounter(props) {
  let { addCounter } = useCounterContext();
  return (
    <>
      <center>
        <button onClick={addCounter}>Add New Counter</button>
      </center>
    </>
  );
}

export default AddCounter;
