import { useCounterContext } from "../context/CounterContext";

function Counter(props) {
  let { count, index } = props;
  let { updateCounter, deleteCounter } = useCounterContext();
  return (
    <>
      <center>
        <h1>{count}</h1>
        <button onClick={() => updateCounter(index)}>Inc</button>
        <button onClick={() => deleteCounter(index)}>Delete</button>
      </center>
    </>
  );
}

export default Counter;
