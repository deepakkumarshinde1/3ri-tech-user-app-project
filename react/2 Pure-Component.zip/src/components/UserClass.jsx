import React from "react";
import ChildComponent from "./ChildComponent";

class UserCLass extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 0, square: 2 };
  }
  incCount = () => {
    // this.setState({ count: this.state.count + 1 });
    this.setState((state) => ({ ...state, count: state.count + 1 }));
  };
  squareNumber = () => {
    this.setState((state) => {
      return { ...state, square: state.square * state.square };
    });
  };
  render() {
    return (
      <>
        <div>
          <h1>Parent Component {this.state.count} </h1>
          <button onClick={this.incCount}>INC Count</button>
          <button onClick={this.squareNumber}>INC Square</button>
        </div>
        <ChildComponent square={this.state.square} />
      </>
    );
  }
}

export default UserCLass;

// bs4 ==> ml , mr
// bs5 ==> ms , me

// Legacy Project
// Class  < 16.8 < Function (Hooks functions)

// store "Welcome User" in a variable
// Events ==> User Action
