import React from "react";

class ChildComponent extends React.PureComponent {
  constructor(props) {
    super(props);
    console.log("child component");
  }

  render() {
    console.log("render child component");
    return <>This child component {this.props.square}</>;
  }
}

export default ChildComponent;
